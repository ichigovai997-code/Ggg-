# Farmer's Rework (Fabric 1.21.1) - by iamnotplaying__

## Build the jar
Option A (local): install JDK 21 + Gradle 8.10+, then run `gradle build`. Jar: `build/libs/farmers-rework-1.0.0.jar`.
Option B (no install): push this folder to a GitHub repo -> Actions tab -> "build" -> download the artifact.

Requires Fabric Loader 0.16+ and Fabric API for 1.21.1.

## Features
- Right-click a ripe crop to harvest + auto-replant (wheat, carrot, potato, beetroot and all new crops)
- Rich Fertilizer: grows crops in a 3x3 area
- Giant Pumpkin / Giant Melon: craft Giant Seeds from 5 normal seeds, plant on farmland, grows into a giant block
- New crops: Tomato, Lettuce, Onion, Corn, Strawberry
- Fruit trees: Orange, Cherry, Peach (saplings, ripening leaves - right-click ripe leaves to pick; generate in plains/forests)
- 20 new foods (soups, salad, pies, juices, cooked corn/tomato, chips ...)
- Farmer villagers trade all new crops/foods/seeds
- Hoe enchantments (librarian trades): Replenish, Baby Crops
- Farmer's Bag: 27-slot bag for crops/seeds/fruit (right-click)
- New villager profession: Orchardist (workstation: Fruit Crate)
- Textures are procedurally generated placeholders - replace freely.
