package com.mrteyvat.enjouu;

import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.random.Random;

/** Chat helper + all the lines the NPCs say. Edit the arrays to change their dialogue. */
public final class Chat {
    private Chat() {
    }

    public static final String[] RAIHAN_DRUNK = {
            "Hic! Bhai, tui ki amar bondhu?",
            "ayy tor vhortasi... duniya ta ghurche!",
            "Ek tan cigarette dibi, bhai?",
            "Deshi wine ta ki je mishti... hic!",
            "Oi gachta amake dekhche, tai na?",
            "Ami bokachoda! naki bhul bolchi?",
            "Ami thik achi... ami thik... wait, ami kothay?",
            "Dara vhai pani keye ashi",
            "Tui sera bhai, hic, sera!",
            "Sahil ke dekhle bolish, ami ready!"
    };
    public static final String[] RAIHAN_FIGHT = {
            "Aye Sahil, gorur bhokto, aay vhortasi hala!",
            "Cde dimu bncd",
            "Biri keye cool hoye jabi",
            "Tor gorur dudh-o amake harate parbe na!",
            "Gorur dhon vore dibo",
            "Chutya naki re!",
            "Shala chat dellet mar",
            "Ladle biri 100 tk holeo kamu",
            "Hic... tui amar sathe pararbi na!",
            "Bokachoda! amr 12ta gf ace",
            "Chutya kothakar!"
    };
    public static final String[] SAHIL_FIGHT = {
            "Raihan, tui ekta bokachoda!",
            "Amar gorura tor cheye beshi sensible!",
            "Gorut mut khaiye dibo tore",
            "Ullu! Cigarette-er dhon tor brain khaiche!",
            "Chudna! Aaj tore dudh khaiye mere debo!",
            "Moo-ve out of my way, drunkard!",
            "Tor ei bottle ta ami bhenge tor pachay vorr dibo! hala."
    };
    public static final String[] SAHIL_COW = {
            "Moo moo! Gai amar jaan!",
            "Mon chay goru dekhe goon kore dey",
            "Goru sudbo ajke! hehe!",
            "Gai dekhle amar mon r dhon bhalo hoye jay!",
            "Ei gai ta ekdom cute!",
            "Love you Goru",
            "Kheye nao, gai-ra, kheye nao!"
    };
    public static final String[] SAHIL_SCARE = {
            "BOO! Hehe, dekh hala baccha ta kemon dour dilo!",
            "Baccha teri mkc",
            "Voy paili?",
            "Basement a vore dibo",
            "Boo! Just kidding, baccha!"
    };
    public static final String[] ANMOL_HELLO = {
            "Meow! Dekhe jao amar cat shop!",
            "Cat armour chai? Ami ache!",
            "Purr... diamond thakle cat free-te dibo!",
            "Billi ke bhalobasho, bhai!"
    };
    public static final String[] RETREAT = {
            "Hosh... ami ektu break nicchi!",
            "Ahh, ami haar manlam... aaj-er moto!",
            "Time-out! Ami ektu rest nei..."
    };

    public static String pick(String[] lines, Random r) {
        return lines[r.nextInt(lines.length)];
    }

    public static void say(MobEntity mob, String name, Formatting color, String line, double radius) {
        if (!(mob.getWorld() instanceof ServerWorld sw)) return;
        Text t = Text.literal("<" + name + "> ").formatted(color).append(Text.literal(line).formatted(Formatting.WHITE));
        for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(mob) <= radius * radius)) {
            p.sendMessage(t, false);
        }
    }
}
