package com.mrteyvat.enjouu.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

import java.util.function.Supplier;

/** A crop that can be planted on farmland OR plain dirt/grass (so it can also grow wild). */
public class EnjouuCropBlock extends CropBlock {
    public static final MapCodec<EnjouuCropBlock> CODEC = createCodec(s -> new EnjouuCropBlock(s, () -> Items.WHEAT_SEEDS));
    private final Supplier<Item> seeds;

    public EnjouuCropBlock(Settings settings, Supplier<Item> seeds) {
        super(settings);
        this.seeds = seeds;
    }

    @Override
    public MapCodec<? extends CropBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected ItemConvertible getSeedsItem() {
        return seeds.get();
    }

    @Override
    public boolean canPlantOnTop(BlockState floor, BlockView world, BlockPos pos) {
        return floor.isOf(Blocks.FARMLAND) || floor.isIn(BlockTags.DIRT);
    }
}
