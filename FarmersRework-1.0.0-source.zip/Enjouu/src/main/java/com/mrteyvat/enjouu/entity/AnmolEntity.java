package com.mrteyvat.enjouu.entity;

import com.mrteyvat.enjouu.Chat;
import com.mrteyvat.enjouu.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.WanderingTraderEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Formatting;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import net.minecraft.village.TradedItem;
import net.minecraft.world.World;

/** Anmol: cat lover and trader. Sells cat spawn eggs and the Meow Plating needed for Cat Armour. */
public class AnmolEntity extends WanderingTraderEntity {
    private int chatCooldown;

    public AnmolEntity(EntityType<? extends WanderingTraderEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 250.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.5)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 16.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.4);
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new StopFollowingCustomerGoal(this));
        goalSelector.add(1, new LookAtCustomerGoal(this));
        goalSelector.add(4, new WanderAroundFarGoal(this, 0.5));
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(6, new LookAroundGoal(this));
    }

    @Override
    protected void fillRecipes() {
        TradeOfferList o = getOffers();
        // Cat spawn eggs
        o.add(new TradeOffer(new TradedItem(Items.DIAMOND, 1), new ItemStack(Items.CAT_SPAWN_EGG, 1), 8, 10, 0.05f));
        o.add(new TradeOffer(new TradedItem(Items.GOLD_INGOT, 6), new ItemStack(Items.CAT_SPAWN_EGG, 1), 12, 5, 0.05f));
        o.add(new TradeOffer(new TradedItem(Items.NETHERITE_SCRAP, 1), new ItemStack(Items.CAT_SPAWN_EGG, 3), 4, 15, 0.05f));
        o.add(new TradeOffer(new TradedItem(Items.NETHERITE_INGOT, 1), new ItemStack(Items.CAT_SPAWN_EGG, 8), 2, 30, 0.05f));
        // Cat Armour crafting material (only available here)
        o.add(new TradeOffer(new TradedItem(Items.GOLD_INGOT, 5), new ItemStack(ModItems.MEOW_PLATING, 1), 8, 10, 0.05f));
        o.add(new TradeOffer(new TradedItem(Items.DIAMOND, 1), new ItemStack(ModItems.MEOW_PLATING, 2), 4, 15, 0.05f));
        // He loves buying fish for his cats
        o.add(new TradeOffer(new TradedItem(Items.COD, 8), new ItemStack(Items.EMERALD, 1), 16, 2, 0.05f));
        o.add(new TradeOffer(new TradedItem(Items.SALMON, 8), new ItemStack(Items.EMERALD, 1), 16, 2, 0.05f));
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (chatCooldown > 0) chatCooldown--;
        if (chatCooldown == 0 && age % 20 == 0 && !hasCustomer()) {
            ServerWorld sw = (ServerWorld) getWorld();
            if (!sw.getPlayers(p -> p.squaredDistanceTo(this) < 36).isEmpty()) {
                Chat.say(this, "Anmol", Formatting.LIGHT_PURPLE, Chat.pick(Chat.ANMOL_HELLO, random), 6);
                chatCooldown = 300 + random.nextInt(300);
            }
        }
    }
}
