package com.mrteyvat.enjouu.entity;

import com.mrteyvat.enjouu.Chat;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/** Shared logic for Raihan and Sahil: 250 HP, rivalry fights, chat lines and the "time-out" when badly hurt. */
public abstract class EnjouuBase extends PathAwareEntity {
    public int calm;
    protected int chatCooldown;
    protected final String npcName;
    protected final Formatting color;

    protected EnjouuBase(EntityType<? extends PathAwareEntity> type, World world, String name, Formatting color) {
        super(type, world);
        this.npcName = name;
        this.color = color;
    }

    public static DefaultAttributeContainer.Builder baseAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 250.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.23)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.4);
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    protected abstract String[] fightLines();

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient) serverTick();
    }

    protected void serverTick() {
        if (calm > 0) calm--;
        if (chatCooldown > 0) chatCooldown--;
        if (calm <= 0 && getHealth() < getMaxHealth() * 0.25f) {
            calm = 1200;
            setTarget(null);
            getNavigation().stop();
            addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 900, 4));
            Chat.say(this, npcName, color, Chat.pick(Chat.RETREAT, random), 24);
        }
        LivingEntity t = getTarget();
        if (t instanceof EnjouuBase && chatCooldown == 0) {
            Chat.say(this, npcName, color, Chat.pick(fightLines(), random), 24);
            chatCooldown = 70 + random.nextInt(60);
        }
    }
}
